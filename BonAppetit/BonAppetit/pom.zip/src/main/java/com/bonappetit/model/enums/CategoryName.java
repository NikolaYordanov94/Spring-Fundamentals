package com.bonappetit.model.enums;

public enum CategoryName {
    MAIN_DISH,
    DESSERT,
    COCKTAIL
}
